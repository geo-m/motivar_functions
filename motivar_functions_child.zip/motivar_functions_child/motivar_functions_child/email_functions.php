<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/*
add_filter('mandrill_payload', 'Hd_Mandrill_choise');

function Hd_Mandrill_choise($message)
{

}
*/
