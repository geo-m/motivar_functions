(function($) {
    "use strict";
    $(document).ready(function() {
        $(window).resize(function() {
            myresize();
        });

        /*Enable only one taxonomy selection*/
        var taxonomies = [];
        if (taxonomies.length > 0) {
            $.each(taxonomies, function(index, value) {
                if ($('#' + value + 'div').length > 0) {
                    $('#' + value + '-all input[type=checkbox]').on('change', function() {
                        $('#' + value + '-all input[type=checkbox]').not(this).prop('checked', false);
                    });
                }
            });
        }


    });

    function myresize() {

    }

})(jQuery);
