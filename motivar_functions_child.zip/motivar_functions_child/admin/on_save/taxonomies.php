<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/*
add_action('create_term','custom_functions_update');
add_action('edit_term', 'custom_functions_update');
add_action('delete_term', 'custom_functions_delete');

function custom_functions_update($term_id)
{

if (isset($_POST['taxonomy']))
	{
		if ($_POST['taxonomy'] == 'portfolio_category')
		{
			update_term_meta( $term_id, 'motivar_functions_prior',(int)$_POST['motivar_functions_prior']);
		}

	}
}
function custom_functions_delete($term_id)
{

}
*/

