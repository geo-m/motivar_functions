<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/*
if ( ! wp_next_scheduled( 'mycron_job' ) ) {
  wp_schedule_event(time(),'daily', ',mycron_job');
  }

add_action('mycron_job','mycrons');


function mycrons() {

}
*/
