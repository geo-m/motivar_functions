(function($) {
  "use strict";
  $(document).ready(function() {
  	myresize();
  $(window).resize(function() {
      myresize();
    });

  });

 function myresize() {

  }

})(jQuery);